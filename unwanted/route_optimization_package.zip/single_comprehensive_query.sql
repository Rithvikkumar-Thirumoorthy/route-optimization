-- SINGLE COMPREHENSIVE QUERY
-- Find sales agents with <60 customers, some without address3, and prospects available
-- Demonstrates the matching function: routedata.address3 = prospective.barangay_code

SELECT
    r.SalesManTerritory as agent_id,
    r.RouteDate as day,
    COUNT(DISTINCT r.CustNo) as total_customers,
    COUNT(DISTINCT CASE
        WHEN r.address3 IS NOT NULL AND r.address3 != '#' AND r.address3 != ''
        THEN r.CustNo
    END) as customers_with_address3,
    COUNT(DISTINCT CASE
        WHEN r.address3 IS NULL OR r.address3 = '#' OR r.address3 = ''
        THEN r.CustNo
    END) as customers_without_address3,
    COUNT(DISTINCT CASE
        WHEN r.latitude IS NULL OR r.longitude IS NULL OR r.latitude = 0 OR r.longitude = 0
        THEN r.CustNo
    END) as stop100_customers,
    r.address3 as barangay_code,
    COUNT(DISTINCT p.CustNo) as matched_prospects,
    (60 - COUNT(DISTINCT r.CustNo)) as need_to_add,
    CASE
        WHEN COUNT(DISTINCT p.CustNo) >= (60 - COUNT(DISTINCT r.CustNo))
        THEN 'CAN_REACH_60'
        ELSE 'PARTIAL_FILL'
    END as optimization_status,
    'MATCHING_FUNCTION: routedata.address3 = prospective.barangay_code' as matching_logic,
    CONCAT('MATCH(', r.address3, ' = ', r.address3, ') -> ', COUNT(DISTINCT p.CustNo), ' prospects') as function_result
FROM routedata r
LEFT JOIN prospective p ON r.address3 = p.barangay_code  -- THE MATCHING FUNCTION
    AND p.Latitude IS NOT NULL
    AND p.Longitude IS NOT NULL
    AND p.Latitude != 0
    AND p.Longitude != 0
WHERE r.SalesManTerritory IS NOT NULL
    AND r.address3 IS NOT NULL
    AND r.address3 != '#'
    AND r.address3 != ''
GROUP BY r.SalesManTerritory, r.RouteDate, r.address3
HAVING COUNT(DISTINCT r.CustNo) < 60  -- Less than 60 customers
    AND COUNT(DISTINCT CASE
        WHEN r.address3 IS NULL OR r.address3 = '#' OR r.address3 = ''
        THEN r.CustNo
    END) > 0  -- Some customers without address3
    AND COUNT(DISTINCT p.CustNo) > 0  -- Prospects available
ORDER BY COUNT(DISTINCT p.CustNo) DESC, COUNT(DISTINCT r.CustNo) DESC;