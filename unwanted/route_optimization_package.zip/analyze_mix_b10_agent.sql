-- ANALYSIS FOR SPECIFIC AGENT: MIX-B10 ON 2025-09-03
-- Based on your query structure using Code instead of SalesManTerritory

-- Query 1: Basic agent information
SELECT
    Code as agent_id,
    RouteDate as day,
    COUNT(DISTINCT CustNo) as total_customers,
    COUNT(DISTINCT CASE
        WHEN address3 IS NOT NULL AND address3 != '#' AND address3 != ''
        THEN CustNo
    END) as customers_with_address3,
    COUNT(DISTINCT CASE
        WHEN address3 IS NULL OR address3 = '#' OR address3 = ''
        THEN CustNo
    END) as customers_without_address3,
    COUNT(DISTINCT CASE
        WHEN latitude IS NOT NULL AND longitude IS NOT NULL
        AND latitude != 0 AND longitude != 0
        THEN CustNo
    END) as customers_with_coords,
    COUNT(DISTINCT CASE
        WHEN latitude IS NULL OR longitude IS NULL
        OR latitude = 0 OR longitude = 0
        THEN CustNo
    END) as stop100_customers
FROM routedata
WHERE Code = 'MIX-B10'
AND RouteDate = '2025-09-03'
GROUP BY Code, RouteDate;

-- Query 2: Show all customers for this agent with their data quality
SELECT
    CustNo,
    latitude,
    longitude,
    address3,
    CASE
        WHEN address3 IS NULL THEN 'NULL_ADDRESS3'
        WHEN address3 = '#' THEN 'HASH_ADDRESS3'
        WHEN address3 = '' THEN 'EMPTY_ADDRESS3'
        ELSE 'VALID_ADDRESS3'
    END as address3_status,
    CASE
        WHEN latitude IS NULL OR longitude IS NULL OR latitude = 0 OR longitude = 0
        THEN 'STOP100'
        ELSE 'WITH_COORDS'
    END as coordinate_status
FROM routedata
WHERE Code = 'MIX-B10'
AND RouteDate = '2025-09-03'
ORDER BY address3_status, coordinate_status, CustNo;

-- Query 3: Get unique barangay codes for this agent
SELECT DISTINCT
    address3 as barangay_code,
    COUNT(DISTINCT CustNo) as customers_with_this_code
FROM routedata
WHERE Code = 'MIX-B10'
AND RouteDate = '2025-09-03'
AND address3 IS NOT NULL
AND address3 != '#'
AND address3 != ''
GROUP BY address3
ORDER BY COUNT(DISTINCT CustNo) DESC;

-- Query 4: Check prospects available for each barangay code
-- This shows the matching function: routedata.address3 = prospective.barangay_code
SELECT
    r.address3 as barangay_code,
    COUNT(DISTINCT r.CustNo) as customers,
    COUNT(DISTINCT p.CustNo) as available_prospects,
    'MATCHING: routedata.address3 = prospective.barangay_code' as matching_logic
FROM routedata r
LEFT JOIN prospective p ON r.address3 = p.barangay_code  -- THE MATCHING FUNCTION
    AND p.Latitude IS NOT NULL
    AND p.Longitude IS NOT NULL
    AND p.Latitude != 0
    AND p.Longitude != 0
WHERE r.Code = 'MIX-B10'
AND r.RouteDate = '2025-09-03'
AND r.address3 IS NOT NULL
AND r.address3 != '#'
AND r.address3 != ''
GROUP BY r.address3
ORDER BY COUNT(DISTINCT p.CustNo) DESC;

-- Query 5: Complete optimization analysis for this agent
SELECT
    r.Code as agent_id,
    r.RouteDate as day,
    COUNT(DISTINCT r.CustNo) as current_customers,
    COUNT(DISTINCT CASE
        WHEN r.address3 IS NOT NULL AND r.address3 != '#' AND r.address3 != ''
        THEN r.CustNo
    END) as customers_with_valid_address3,
    COUNT(DISTINCT CASE
        WHEN r.address3 IS NULL OR r.address3 = '#' OR r.address3 = ''
        THEN r.CustNo
    END) as customers_without_valid_address3,
    COUNT(DISTINCT p.CustNo) as total_prospects_available,
    (60 - COUNT(DISTINCT r.CustNo)) as need_to_reach_60,
    CASE
        WHEN COUNT(DISTINCT p.CustNo) >= (60 - COUNT(DISTINCT r.CustNo))
        THEN 'CAN_REACH_60_WITH_PROSPECTS'
        WHEN COUNT(DISTINCT p.CustNo) > 0
        THEN 'PARTIAL_FILL_POSSIBLE'
        ELSE 'NO_PROSPECTS_AVAILABLE'
    END as optimization_potential,
    STRING_AGG(DISTINCT r.address3, ', ') as barangay_codes_used
FROM routedata r
LEFT JOIN prospective p ON r.address3 = p.barangay_code  -- THE MATCHING FUNCTION
    AND p.Latitude IS NOT NULL
    AND p.Longitude IS NOT NULL
    AND p.Latitude != 0
    AND p.Longitude != 0
WHERE r.Code = 'MIX-B10'
AND r.RouteDate = '2025-09-03'
GROUP BY r.Code, r.RouteDate;

-- Query 6: Show sample prospects that would be added
-- Based on the matching function results
SELECT TOP 10
    p.CustNo as prospect_id,
    p.Latitude,
    p.Longitude,
    p.barangay_code,
    r.address3 as customer_barangay_code,
    'MATCH_CONFIRMED' as matching_status
FROM routedata r
INNER JOIN prospective p ON r.address3 = p.barangay_code  -- THE MATCHING FUNCTION
WHERE r.Code = 'MIX-B10'
AND r.RouteDate = '2025-09-03'
AND r.address3 IS NOT NULL
AND r.address3 != '#'
AND r.address3 != ''
AND p.Latitude IS NOT NULL
AND p.Longitude IS NOT NULL
AND p.Latitude != 0
AND p.Longitude != 0
ORDER BY p.CustNo;

-- Query 7: Route optimization simulation
-- Shows what the final route would look like
SELECT
    'CURRENT_CUSTOMERS' as customer_type,
    CustNo,
    latitude,
    longitude,
    address3 as barangay_code,
    CASE
        WHEN latitude IS NULL OR longitude IS NULL OR latitude = 0 OR longitude = 0
        THEN 100  -- Stop100 for customers without coordinates
        ELSE ROW_NUMBER() OVER (ORDER BY CustNo)  -- Sequential stop numbers for TSP
    END as suggested_stopno
FROM routedata
WHERE Code = 'MIX-B10'
AND RouteDate = '2025-09-03'

UNION ALL

SELECT
    'ADDED_PROSPECTS' as customer_type,
    p.CustNo,
    p.Latitude as latitude,
    p.Longitude as longitude,
    p.barangay_code,
    (SELECT COUNT(DISTINCT CustNo) FROM routedata WHERE Code = 'MIX-B10' AND RouteDate = '2025-09-03')
    + ROW_NUMBER() OVER (ORDER BY p.CustNo) as suggested_stopno
FROM routedata r
INNER JOIN prospective p ON r.address3 = p.barangay_code  -- THE MATCHING FUNCTION
WHERE r.Code = 'MIX-B10'
AND r.RouteDate = '2025-09-03'
AND r.address3 IS NOT NULL
AND r.address3 != '#'
AND r.address3 != ''
AND p.Latitude IS NOT NULL
AND p.Longitude IS NOT NULL
AND p.Latitude != 0
AND p.Longitude != 0
AND p.CustNo IN (
    SELECT TOP 20 p2.CustNo  -- Add up to 20 prospects to reach closer to 60
    FROM routedata r2
    INNER JOIN prospective p2 ON r2.address3 = p2.barangay_code
    WHERE r2.Code = 'MIX-B10'
    AND r2.RouteDate = '2025-09-03'
    AND p2.Latitude IS NOT NULL
    AND p2.Longitude IS NOT NULL
    ORDER BY p2.CustNo
)
ORDER BY customer_type, suggested_stopno;