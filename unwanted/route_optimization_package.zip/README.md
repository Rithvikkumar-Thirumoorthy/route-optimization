# Route Optimization Package

## Files Included:

### Core Pipeline Files:
- run_specific_agents.py - Main script to run pipeline for specific agents
- scalable_route_optimizer.py - Optimized for large datasets (5.8M prospects)
- enhanced_route_optimizer.py - Base route optimizer with TSP
- database.py - Database connection module

### SQL Queries:
- scenario_specific_queries.sql - All analysis queries by scenario
- single_comprehensive_query.sql - Single query for complex analysis
- analysis_queries.sql - Complete query collection
- find_agents_25_to_59.sql - Find agents with 25-59 customers
- check_agents_with_prospects.sql - Check prospect availability

### Performance & Setup:
- create_indexes.py - Create database performance indexes
- create_optimized_indexes.sql - Index creation SQL
- run_production_pipeline.py - Full production pipeline
- test_performance.py - Performance testing

## Key Matching Logic:
routedata.address3 = prospective.barangay_code

## Usage:
1. Set up database connection in .env file
2. Run create_indexes.py for performance
3. Use run_specific_agents.py for targeted processing
4. Use scenario queries for analysis

## Barangay Code Fix Applied:
- Customers: Use address3 from routedata
- Prospects: Use Barangay_code from prospective table
