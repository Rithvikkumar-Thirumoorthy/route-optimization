#!/bin/bash
# Prepare hierarchical-route-pipeline for distribution
# This script cleans up temporary files before creating archive

set -e

echo "================================================================================"
echo "          PREPARING DISTRIBUTION PACKAGE"
echo "================================================================================"
echo ""

echo "[1/6] Cleaning Python cache files..."
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find . -type f -name "*.pyc" -delete 2>/dev/null || true
find . -type f -name "*.pyo" -delete 2>/dev/null || true
echo "Done."

echo "[2/6] Cleaning log files..."
rm -f logs/*.log 2>/dev/null || true
echo "Done."

echo "[3/6] Removing virtual environments..."
rm -rf venv env 2>/dev/null || true
echo "Done."

echo "[4/6] Removing credentials file (.env)..."
if [ -f .env ]; then
    rm -f .env
    echo "WARNING: .env file was removed!"
else
    echo "OK: No .env file found."
fi

echo "[5/6] Removing OS-specific files..."
find . -name ".DS_Store" -delete 2>/dev/null || true
find . -name "Thumbs.db" -delete 2>/dev/null || true
echo "Done."

echo "[6/6] Verifying required files..."
missing_files=""
for file in README.md requirements.txt .env.example config.py run_pipeline.py; do
    if [ ! -f "$file" ]; then
        missing_files="$missing_files $file"
    fi
done

if [ -n "$missing_files" ]; then
    echo "ERROR: Missing required files:$missing_files"
    exit 1
else
    echo "All required files present."
fi

echo ""
echo "================================================================================"
echo "                   CLEANUP COMPLETE!"
echo "================================================================================"
echo ""
echo "The project is ready for distribution."
echo ""
echo "Next steps:"
echo "  1. Review DISTRIBUTION_CHECKLIST.md for final checks"
echo "  2. Create archive:"
echo "     cd .."
echo "     tar -czf hierarchical-route-pipeline-v1.0.0.tar.gz hierarchical-route-pipeline/"
echo ""
echo "  OR create ZIP:"
echo "     zip -r hierarchical-route-pipeline-v1.0.0.zip hierarchical-route-pipeline/"
echo ""
echo "================================================================================"
