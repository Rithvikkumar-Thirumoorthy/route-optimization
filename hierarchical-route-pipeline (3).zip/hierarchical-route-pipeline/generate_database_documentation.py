#!/usr/bin/env python3
"""
Generate comprehensive database documentation for Hierarchical Route Pipeline
Creates a .docx file documenting all tables, queries, columns, and purposes
"""

import os
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from datetime import datetime

def add_heading_with_color(doc, text, level, color=(0, 51, 102)):
    """Add a colored heading to the document"""
    heading = doc.add_heading(text, level=level)
    for run in heading.runs:
        run.font.color.rgb = RGBColor(*color)
    return heading

def add_table_with_style(doc, rows, cols):
    """Add a table with custom styling"""
    table = doc.add_table(rows=rows, cols=cols)
    table.style = 'Light Grid Accent 1'
    return table

def set_cell_background(cell, color):
    """Set background color for a table cell"""
    shading_elm = OxmlElement('w:shd')
    shading_elm.set(qn('w:fill'), color)
    cell._element.get_or_add_tcPr().append(shading_elm)

def create_database_documentation():
    """Create comprehensive database documentation"""
    doc = Document()

    # Title page
    title = doc.add_heading('Database Documentation', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in title.runs:
        run.font.color.rgb = RGBColor(0, 51, 102)

    subtitle = doc.add_paragraph('Hierarchical Route Optimization Pipeline')
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle_run = subtitle.runs[0]
    subtitle_run.font.size = Pt(16)
    subtitle_run.font.color.rgb = RGBColor(128, 128, 128)

    date_para = doc.add_paragraph(f'Generated: {datetime.now().strftime("%B %d, %Y")}')
    date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_page_break()

    # Table of Contents
    add_heading_with_color(doc, 'Table of Contents', 1)
    toc_items = [
        '1. Overview',
        '2. Database Tables Summary',
        '3. Table 1: MonthlyRoutePlan_temp',
        '4. Table 2: customer',
        '5. Table 3: prospective',
        '6. Table 4: custvisit',
        '7. Table 5: distributors',
        '8. Data Flow Summary',
        '9. Query Reference'
    ]
    for item in toc_items:
        doc.add_paragraph(item, style='List Number')

    doc.add_page_break()

    # 1. Overview
    add_heading_with_color(doc, '1. Overview', 1)
    doc.add_paragraph(
        'This document provides comprehensive documentation of all database tables, '
        'columns, and queries used in the Hierarchical Route Optimization Pipeline. '
        'The pipeline processes monthly route plans in a hierarchical manner: '
        'Distributor → Agent → Date.'
    )

    doc.add_paragraph(
        'The primary objective is to optimize delivery routes using TSP (Traveling Salesman Problem) '
        'algorithm and enrich routes with prospective customers to reach target route sizes.'
    )

    # 2. Database Tables Summary
    add_heading_with_color(doc, '2. Database Tables Summary', 1)

    table = add_table_with_style(doc, 6, 3)

    # Header row
    header_cells = table.rows[0].cells
    header_cells[0].text = 'Table Name'
    header_cells[1].text = 'Purpose'
    header_cells[2].text = 'Operations'
    for cell in header_cells:
        set_cell_background(cell, '4472C4')
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
                run.font.color.rgb = RGBColor(255, 255, 255)

    # Data rows
    tables_data = [
        ['MonthlyRoutePlan_temp', 'Main target table storing optimized route plans', 'SELECT, UPDATE, INSERT'],
        ['customer', 'Customer master data with GPS coordinates', 'SELECT (JOIN)'],
        ['prospective', 'Prospective customers to add to routes', 'SELECT (JOIN)'],
        ['custvisit', 'Customer visit history tracking', 'SELECT (EXISTS check)'],
        ['distributors', 'Distributor locations for TSP starting points', 'SELECT']
    ]

    for idx, row_data in enumerate(tables_data, start=1):
        row = table.rows[idx]
        for col_idx, value in enumerate(row_data):
            row.cells[col_idx].text = value

    doc.add_page_break()

    # 3. MonthlyRoutePlan_temp
    add_heading_with_color(doc, '3. Table: MonthlyRoutePlan_temp', 1)

    add_heading_with_color(doc, '3.1 Overview', 2, (70, 130, 180))
    doc.add_paragraph(
        'Primary table that stores the monthly route plan data. This table is both the source '
        'and target of the optimization process. The pipeline reads existing route assignments, '
        'optimizes them using TSP, and updates the StopNo field with the optimized sequence.'
    )

    add_heading_with_color(doc, '3.2 Columns', 2, (70, 130, 180))

    table = add_table_with_style(doc, 13, 2)

    # Header
    header_cells = table.rows[0].cells
    header_cells[0].text = 'Column Name'
    header_cells[1].text = 'Purpose'
    for cell in header_cells:
        set_cell_background(cell, '70C4A4')
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True

    # Columns data
    columns = [
        ['DistributorID', 'Identifies which distributor the route belongs to'],
        ['AgentID', 'Identifies the sales agent assigned to the route'],
        ['RouteDate', 'Date when the route will be executed'],
        ['CustNo', 'Customer/prospect identifier'],
        ['StopNo', 'Sequence number (UPDATED by TSP) - determines visit order'],
        ['Name', 'Customer/prospect name'],
        ['WD', 'Work day identifier (1-7)'],
        ['SalesManTerritory', 'Sales territory code'],
        ['RouteName', 'Name of the route'],
        ['RouteCode', 'Route code identifier'],
        ['SalesOfficeID', 'Sales office identifier'],
        ['custype', "Identifies 'customer' or 'prospect'"]
    ]

    for idx, col_data in enumerate(columns, start=1):
        row = table.rows[idx]
        for col_idx, value in enumerate(col_data):
            row.cells[col_idx].text = value

    add_heading_with_color(doc, '3.3 Queries', 2, (70, 130, 180))

    # Query 1: Hierarchy Building
    doc.add_paragraph('Query 1: Build Hierarchical Structure', style='Heading 3')
    doc.add_paragraph('Purpose: Get all distributor-agent-date combinations for processing', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''SELECT
    DistributorID,
    AgentID,
    RouteDate,
    COUNT(DISTINCT CustNo) as customer_count,
    COUNT(*) as total_records
FROM MonthlyRoutePlan_temp
WHERE DistributorID IS NOT NULL
    AND AgentID IS NOT NULL
    AND RouteDate IS NOT NULL
    AND CustNo IS NOT NULL
    {distributor_filter}
GROUP BY DistributorID, AgentID, RouteDate
ORDER BY DistributorID, AgentID, RouteDate ASC''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Returns: Hierarchy of all combinations to process with customer counts', style='Body Text 2')

    # Query 2: Get Route Data
    doc.add_paragraph('Query 2: Get Route Data for Processing', style='Heading 3')
    doc.add_paragraph('Purpose: Retrieve existing route assignments for a specific combination', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''SELECT
    CustNo, RouteDate, Name, WD, SalesManTerritory,
    AgentID, RouteName, DistributorID, RouteCode,
    SalesOfficeID
FROM MonthlyRoutePlan_temp
WHERE DistributorID = '{distributor_id}'
    AND AgentID = '{agent_id}'
    AND RouteDate = '{route_date}'
    AND CustNo IS NOT NULL''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Returns: All customers assigned to this specific route', style='Body Text 2')

    # Query 3: Update StopNo
    doc.add_paragraph('Query 3: Update Optimized StopNo', style='Heading 3')
    doc.add_paragraph('Purpose: Update route sequence with TSP-optimized stop numbers', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''UPDATE MonthlyRoutePlan_temp
SET StopNo = ?
WHERE DistributorID = ?
    AND AgentID = ?
    AND RouteDate = ?
    AND CustNo = ?''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Executed: Via batch executemany() for performance', style='Body Text 2')

    # Query 4: Insert Prospects
    doc.add_paragraph('Query 4: Insert Prospects into Route', style='Heading 3')
    doc.add_paragraph('Purpose: Add new prospects to the route plan', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''INSERT INTO MonthlyRoutePlan_temp
(DistributorID, AgentID, RouteDate, CustNo, StopNo,
 Name, WD, SalesManTerritory, RouteName, RouteCode, SalesOfficeID)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Executed: Via batch executemany() for multiple prospects', style='Body Text 2')

    # Query 5: Update custype
    doc.add_paragraph('Query 5: Update Customer Type (custype)', style='Heading 3')
    doc.add_paragraph('Purpose: Mark records as customer or prospect', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''-- For customers
UPDATE MonthlyRoutePlan_temp
SET custype = 'customer'
FROM MonthlyRoutePlan_temp m
INNER JOIN customer c ON m.CustNo = c.CustNo
WHERE m.custype IS NULL OR m.custype = ''

-- For prospects
UPDATE MonthlyRoutePlan_temp
SET custype = 'prospect'
FROM MonthlyRoutePlan_temp m
INNER JOIN prospective p ON m.CustNo = p.tdlinx
WHERE m.custype IS NULL OR m.custype = ''
''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Executed: Post-processing phase after all routes optimized', style='Body Text 2')

    doc.add_page_break()

    # 4. customer table
    add_heading_with_color(doc, '4. Table: customer', 1)

    add_heading_with_color(doc, '4.1 Overview', 2, (70, 130, 180))
    doc.add_paragraph(
        'Master table containing customer information including GPS coordinates. '
        'This table is essential for TSP route optimization as it provides the latitude '
        'and longitude for each customer location.'
    )

    add_heading_with_color(doc, '4.2 Columns', 2, (70, 130, 180))

    table = add_table_with_style(doc, 5, 2)

    # Header
    header_cells = table.rows[0].cells
    header_cells[0].text = 'Column Name'
    header_cells[1].text = 'Purpose'
    for cell in header_cells:
        set_cell_background(cell, '70C4A4')
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True

    # Columns
    columns = [
        ['CustNo', 'Unique customer identifier (JOIN key)'],
        ['latitude', 'GPS latitude for TSP optimization & distance calculations'],
        ['longitude', 'GPS longitude for TSP optimization & distance calculations'],
        ['address3', 'Barangay/area code for prospect matching']
    ]

    for idx, col_data in enumerate(columns, start=1):
        row = table.rows[idx]
        for col_idx, value in enumerate(col_data):
            row.cells[col_idx].text = value

    add_heading_with_color(doc, '4.3 Queries', 2, (70, 130, 180))

    # Query 1: Get Customer Coordinates
    doc.add_paragraph('Query 1: Get Customer Coordinates (Batch)', style='Heading 3')
    doc.add_paragraph('Purpose: Fetch GPS coordinates for route customers with caching', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''SELECT
    CustNo, latitude, longitude, address3 as barangay_code
FROM customer
WHERE CustNo IN ('{customer_nos}')
    AND latitude IS NOT NULL
    AND longitude IS NOT NULL
    AND latitude != 0.0
    AND longitude != 0.0
    AND ABS(latitude) > 0.000001
    AND ABS(longitude) > 0.000001''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Optimization: Results cached per CustNo to avoid repeated queries', style='Body Text 2')
    doc.add_paragraph('Returns: Valid GPS coordinates for TSP optimization', style='Body Text 2')

    # Query 2: Get Barangay Codes
    doc.add_paragraph('Query 2: Get Barangay Codes (Fallback)', style='Heading 3')
    doc.add_paragraph('Purpose: Get area codes when coordinates unavailable', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''SELECT DISTINCT address3
FROM customer
WHERE CustNo IN ('{customer_nos}')
    AND address3 IS NOT NULL
    AND address3 != ''
''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Returns: Barangay codes used for prospect matching', style='Body Text 2')

    # Query 3: Detect custype
    doc.add_paragraph('Query 3: Detect Customer Type', style='Heading 3')
    doc.add_paragraph('Purpose: Identify if CustNo is an existing customer', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''SELECT CustNo, 'customer' as custype
FROM customer
WHERE CustNo IN ('{customer_nos}')''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Returns: Customer type classification', style='Body Text 2')

    doc.add_page_break()

    # 5. prospective table
    add_heading_with_color(doc, '5. Table: prospective', 1)

    add_heading_with_color(doc, '5.1 Overview', 2, (70, 130, 180))
    doc.add_paragraph(
        'Contains prospective customers (potential new customers) that can be added to routes. '
        'The pipeline searches this table to fill routes to the target size of 60 customers. '
        'Prospects are matched based on barangay (area) or geographic proximity.'
    )

    add_heading_with_color(doc, '5.2 Columns', 2, (70, 130, 180))

    table = add_table_with_style(doc, 6, 2)

    # Header
    header_cells = table.rows[0].cells
    header_cells[0].text = 'Column Name'
    header_cells[1].text = 'Purpose'
    for cell in header_cells:
        set_cell_background(cell, '70C4A4')
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True

    # Columns
    columns = [
        ['tdlinx', 'Prospect ID (maps to CustNo)'],
        ['latitude', 'GPS latitude for TSP & distance calculations'],
        ['longitude', 'GPS longitude for TSP & distance calculations'],
        ['barangay_code', 'Area code for matching to customer locations'],
        ['store_name_nielsen', 'Prospect store name']
    ]

    for idx, col_data in enumerate(columns, start=1):
        row = table.rows[idx]
        for col_idx, value in enumerate(col_data):
            row.cells[col_idx].text = value

    add_heading_with_color(doc, '5.3 Queries', 2, (70, 130, 180))

    # Query 1: Barangay-based search
    doc.add_paragraph('Query 1: Barangay-Based Prospect Search', style='Heading 3')
    doc.add_paragraph('Purpose: Find prospects in same area as existing customers', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''SELECT TOP {needed_prospects}
    p.tdlinx as CustNo, p.latitude, p.longitude,
    p.barangay_code, p.store_name_nielsen as Name
FROM prospective p
LEFT JOIN MonthlyRoutePlan_temp mrp ON mrp.CustNo = p.tdlinx
    AND mrp.DistributorID = '{distributor_id}'
    AND mrp.AgentID = '{agent_id}'
    AND mrp.RouteDate = CONVERT(DATE, '{route_date}')
LEFT JOIN custvisit cv ON cv.CustID = p.tdlinx
WHERE p.barangay_code IN ('{barangay_codes}')
    AND p.latitude IS NOT NULL
    AND p.longitude IS NOT NULL
    AND p.latitude != 0
    AND p.longitude != 0
    AND mrp.CustNo IS NULL
    AND cv.CustID IS NULL
ORDER BY NEWID()''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Exclusions: Already in route (mrp.CustNo IS NULL), Already visited (cv.CustID IS NULL)', style='Body Text 2')
    doc.add_paragraph('Returns: Random selection of prospects in target barangays', style='Body Text 2')

    # Query 2: Location-based search
    doc.add_paragraph('Query 2: Location-Based Prospect Search (Fallback)', style='Heading 3')
    doc.add_paragraph('Purpose: Find nearby prospects using GPS distance (within 5km)', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''SELECT
    tdlinx as CustNo, latitude, longitude,
    barangay_code, store_name_nielsen as Name
FROM prospective
WHERE latitude IS NOT NULL
    AND longitude IS NOT NULL
    AND latitude != 0
    AND longitude != 0
    {exclusion_clause}
    AND NOT EXISTS (
        SELECT 1 FROM MonthlyRoutePlan_temp
        WHERE MonthlyRoutePlan_temp.CustNo = prospective.tdlinx
        AND MonthlyRoutePlan_temp.DistributorID = '{distributor_id}'
        AND MonthlyRoutePlan_temp.AgentID = '{agent_id}'
        AND MonthlyRoutePlan_temp.RouteDate = CONVERT(DATE, '{route_date}')
    )
    AND NOT EXISTS (
        SELECT 1 FROM custvisit
        WHERE custvisit.CustID = prospective.tdlinx
    )''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Post-processing: Haversine distance calculated in Python, filtered to <= 5km', style='Body Text 2')
    doc.add_paragraph('Returns: All unvisited prospects (distance filtering done in code)', style='Body Text 2')

    # Query 3: Detect custype
    doc.add_paragraph('Query 3: Detect Prospect Type', style='Heading 3')
    doc.add_paragraph('Purpose: Identify if CustNo is a prospect', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''SELECT tdlinx as CustNo, 'prospect' as custype
FROM prospective
WHERE tdlinx IN ('{customer_nos}')''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Returns: Prospect type classification', style='Body Text 2')

    doc.add_page_break()

    # 6. custvisit table
    add_heading_with_color(doc, '6. Table: custvisit', 1)

    add_heading_with_color(doc, '6.1 Overview', 2, (70, 130, 180))
    doc.add_paragraph(
        'Tracks customer visit history. This table is used to exclude prospects that have '
        'already been visited, ensuring only unvisited prospects are added to routes.'
    )

    add_heading_with_color(doc, '6.2 Columns', 2, (70, 130, 180))

    table = add_table_with_style(doc, 2, 2)

    # Header
    header_cells = table.rows[0].cells
    header_cells[0].text = 'Column Name'
    header_cells[1].text = 'Purpose'
    for cell in header_cells:
        set_cell_background(cell, '70C4A4')
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True

    # Columns
    columns = [
        ['CustID', 'Customer/prospect ID that was visited - used to exclude visited prospects']
    ]

    for idx, col_data in enumerate(columns, start=1):
        row = table.rows[idx]
        for col_idx, value in enumerate(col_data):
            row.cells[col_idx].text = value

    add_heading_with_color(doc, '6.3 Queries', 2, (70, 130, 180))

    doc.add_paragraph('Query 1: Exclude Visited Prospects', style='Heading 3')
    doc.add_paragraph('Purpose: Filter out prospects that have been visited', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''-- Used within prospect search queries
AND NOT EXISTS (
    SELECT 1 FROM custvisit
    WHERE custvisit.CustID = prospective.tdlinx
)

-- Or using LEFT JOIN
LEFT JOIN custvisit cv ON cv.CustID = p.tdlinx
WHERE cv.CustID IS NULL''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Usage: Subquery/JOIN condition in prospect selection queries', style='Body Text 2')
    doc.add_paragraph('Returns: Ensures only unvisited prospects are selected', style='Body Text 2')

    doc.add_page_break()

    # 7. distributors table
    add_heading_with_color(doc, '7. Table: distributors', 1)

    add_heading_with_color(doc, '7.1 Overview', 2, (70, 130, 180))
    doc.add_paragraph(
        'Contains distributor master data including warehouse/office locations. '
        'These locations serve as the starting point for TSP route optimization. '
        'Each distributor has a specific location, and routes start from that location.'
    )

    add_heading_with_color(doc, '7.2 Columns', 2, (70, 130, 180))

    table = add_table_with_style(doc, 6, 2)

    # Header
    header_cells = table.rows[0].cells
    header_cells[0].text = 'Column Name'
    header_cells[1].text = 'Purpose'
    for cell in header_cells:
        set_cell_background(cell, '70C4A4')
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True

    # Columns
    columns = [
        ['DistributorID', 'Unique distributor identifier'],
        ['Latitude', 'Warehouse/office latitude - used as TSP starting point for route optimization'],
        ['Longitude', 'Warehouse/office longitude - used as TSP starting point for route optimization'],
        ['Name', 'Distributor name (for logging purposes)'],
        ['Address', 'Distributor address (for logging purposes)']
    ]

    for idx, col_data in enumerate(columns, start=1):
        row = table.rows[idx]
        for col_idx, value in enumerate(col_data):
            row.cells[col_idx].text = value

    add_heading_with_color(doc, '7.3 Queries', 2, (70, 130, 180))

    doc.add_paragraph('Query 1: Get Distributor Location', style='Heading 3')
    doc.add_paragraph('Purpose: Fetch distributor warehouse/office location for TSP start point', style='Intense Quote')

    code = doc.add_paragraph()
    code_run = code.add_run('''SELECT TOP 1
    Latitude,
    Longitude,
    Name,
    Address
FROM distributors
WHERE DistributorID = '{distributor_id}'
    AND Latitude IS NOT NULL
    AND Longitude IS NOT NULL
    AND Latitude != 0
    AND Longitude != 0
    AND ABS(Latitude) > 0.000001
    AND ABS(Longitude) > 0.000001''')
    code_run.font.name = 'Courier New'
    code_run.font.size = Pt(9)

    doc.add_paragraph('Optimization: Results cached per DistributorID', style='Body Text 2')
    doc.add_paragraph('Priority: CLI args > distributors table > config defaults', style='Body Text 2')
    doc.add_paragraph('Returns: Starting GPS coordinates for route optimization', style='Body Text 2')

    doc.add_page_break()

    # 8. Data Flow Summary
    add_heading_with_color(doc, '8. Data Flow Summary', 1)

    doc.add_paragraph('The pipeline processes data in the following sequence:')

    doc.add_paragraph('Phase 1: Read Route Combinations', style='Heading 2')
    doc.add_paragraph(
        '• Read from MonthlyRoutePlan_temp\n'
        '• Build hierarchy: DistributorID → AgentID → RouteDate\n'
        '• Count existing customers per route'
    )

    doc.add_paragraph('Phase 2: Enrich with GPS Coordinates', style='Heading 2')
    doc.add_paragraph(
        '• JOIN with customer table on CustNo\n'
        '• Fetch latitude, longitude, address3 (barangay)\n'
        '• Separate customers with/without coordinates'
    )

    doc.add_paragraph('Phase 3: Add Prospects (if route < 60)', style='Heading 2')
    doc.add_paragraph(
        '• Calculate needed prospects: 60 - current_count\n'
        '• Primary: Search prospective by barangay_code match\n'
        '• Fallback: Search prospective by GPS distance (within 5km)\n'
        '• Exclude: Already in route (MonthlyRoutePlan_temp) or visited (custvisit)'
    )

    doc.add_paragraph('Phase 4: TSP Optimization', style='Heading 2')
    doc.add_paragraph(
        '• Get starting point from distributors table\n'
        '• Apply nearest neighbor algorithm using Haversine distance\n'
        '• Generate optimized StopNo sequence (1, 2, 3... N)\n'
        '• Customers without coordinates get StopNo = 100'
    )

    doc.add_paragraph('Phase 5: Update Database', style='Heading 2')
    doc.add_paragraph(
        '• UPDATE MonthlyRoutePlan_temp.StopNo for existing customers\n'
        '• INSERT new prospects into MonthlyRoutePlan_temp\n'
        '• UPDATE custype field to mark customer vs prospect'
    )

    doc.add_paragraph('Phase 6: Post-Processing', style='Heading 2')
    doc.add_paragraph(
        '• Fill remaining gaps with location-based prospect search\n'
        '• Update custype using JOIN with customer and prospective tables\n'
        '• Final validation and logging'
    )

    doc.add_page_break()

    # 9. Query Reference
    add_heading_with_color(doc, '9. Quick Query Reference', 1)

    doc.add_paragraph(
        'This section provides a quick lookup of all queries organized by operation type.'
    )

    add_heading_with_color(doc, '9.1 SELECT Queries', 2, (70, 130, 180))

    table = add_table_with_style(doc, 8, 2)

    # Header
    header_cells = table.rows[0].cells
    header_cells[0].text = 'Table'
    header_cells[1].text = 'Purpose'
    for cell in header_cells:
        set_cell_background(cell, 'FFD966')
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True

    # Data
    selects = [
        ['MonthlyRoutePlan_temp', 'Build hierarchy structure (DistributorID, AgentID, RouteDate combinations)'],
        ['MonthlyRoutePlan_temp', 'Get route data for processing (customers assigned to specific route)'],
        ['customer', 'Get customer coordinates (batch fetch with caching)'],
        ['customer', 'Get barangay codes (fallback when coordinates unavailable)'],
        ['prospective', 'Barangay-based prospect search (match by area)'],
        ['prospective', 'Location-based prospect search (find nearby prospects within 5km)'],
        ['distributors', 'Get distributor location for TSP starting point']
    ]

    for idx, row_data in enumerate(selects, start=1):
        row = table.rows[idx]
        for col_idx, value in enumerate(row_data):
            row.cells[col_idx].text = value

    add_heading_with_color(doc, '9.2 UPDATE Queries', 2, (70, 130, 180))

    table = add_table_with_style(doc, 4, 2)

    # Header
    header_cells = table.rows[0].cells
    header_cells[0].text = 'Table'
    header_cells[1].text = 'Purpose'
    for cell in header_cells:
        set_cell_background(cell, 'A9D18E')
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True

    # Data
    updates = [
        ['MonthlyRoutePlan_temp', 'Update StopNo with TSP-optimized sequence (batch executemany)'],
        ['MonthlyRoutePlan_temp', 'Update custype = customer (JOIN with customer table)'],
        ['MonthlyRoutePlan_temp', 'Update custype = prospect (JOIN with prospective table)']
    ]

    for idx, row_data in enumerate(updates, start=1):
        row = table.rows[idx]
        for col_idx, value in enumerate(row_data):
            row.cells[col_idx].text = value

    add_heading_with_color(doc, '9.3 INSERT Queries', 2, (70, 130, 180))

    table = add_table_with_style(doc, 2, 2)

    # Header
    header_cells = table.rows[0].cells
    header_cells[0].text = 'Table'
    header_cells[1].text = 'Purpose'
    for cell in header_cells:
        set_cell_background(cell, 'F4B084')
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True

    # Data
    inserts = [
        ['MonthlyRoutePlan_temp', 'Insert prospects into routes (batch executemany for multiple prospects)']
    ]

    for idx, row_data in enumerate(inserts, start=1):
        row = table.rows[idx]
        for col_idx, value in enumerate(row_data):
            row.cells[col_idx].text = value

    # Footer
    doc.add_page_break()
    footer_para = doc.add_paragraph()
    footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer_run = footer_para.add_run(
        '--- End of Database Documentation ---\n\n'
        'Hierarchical Route Optimization Pipeline\n'
        f'Generated: {datetime.now().strftime("%B %d, %Y at %H:%M")}'
    )
    footer_run.font.size = Pt(10)
    footer_run.font.color.rgb = RGBColor(128, 128, 128)

    return doc

def main():
    """Main function to generate the document"""
    print("Generating Database Documentation...")

    doc = create_database_documentation()

    output_path = 'Database_Documentation_Route_Pipeline.docx'
    doc.save(output_path)

    print(f"[SUCCESS] Documentation generated successfully: {output_path}")
    print(f"[INFO] File size: {os.path.getsize(output_path) / 1024:.2f} KB")

if __name__ == "__main__":
    main()
