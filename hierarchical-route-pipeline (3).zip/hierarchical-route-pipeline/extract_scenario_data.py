#!/usr/bin/env python3
"""
Standalone Scenario Data Extractor

Analyzes data from MonthlyRoutePlan_temp and categorizes into 3 scenarios:
1. Customer + Prospects with valid coordinates
2. Customer + Prospects in same barangay without coordinates
3. Customer only (no prospects due to missing coords or barangay)

This script runs independently and does NOT modify the pipeline.
"""

import sys
import os
import pandas as pd
from datetime import datetime

# Add src directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.database import DatabaseConnection
from src.scenario_tracker import ScenarioTracker


class ScenarioDataExtractor:
    """Extract and classify scenario data from MonthlyRoutePlan_temp"""

    def __init__(self, output_dir="scenario_outputs"):
        self.output_dir = output_dir
        self.tracker = ScenarioTracker(output_dir=output_dir)
        os.makedirs(output_dir, exist_ok=True)

    def extract_all_scenarios(self):
        """Extract all scenario data from the database"""
        print("=" * 80)
        print(" " * 20 + "SCENARIO DATA EXTRACTION")
        print("=" * 80)
        print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)

        db = None
        try:
            # Connect to database
            db = DatabaseConnection()
            db.connect()
            print("\nConnected to database successfully")

            # Get all unique combinations
            print("\nFetching all distributor-agent-date combinations...")
            combinations = self._get_all_combinations(db)
            print(f"Found {len(combinations)} unique combinations to analyze")

            # Process each combination
            processed = 0
            for idx, combo in enumerate(combinations, 1):
                distributor_id = combo['DistributorID']
                agent_id = combo['AgentID']
                route_date = combo['RouteDate']

                print(f"\n[{idx}/{len(combinations)}] Processing: {distributor_id} / {agent_id} / {route_date}")

                # Analyze this combination
                self._analyze_combination(db, distributor_id, agent_id, route_date)
                processed += 1

                if processed % 10 == 0:
                    print(f"Progress: {processed}/{len(combinations)} combinations processed")

            # Export to CSV
            print("\n" + "=" * 80)
            print("Exporting scenario data to CSV files...")
            print("=" * 80)
            results = self.tracker.export_to_csv(timestamp=True)

            # Print results
            print("\nExport Results:")
            for scenario_type, info in results.items():
                print(f"\n{scenario_type}:")
                print(f"  File: {info['filepath']}")
                print(f"  Records: {info['record_count']}")
                print(f"  Unique Combinations: {info['unique_combinations']}")

            # Print summary
            self.tracker.print_summary()

            print("\n" + "=" * 80)
            print(" " * 20 + "EXTRACTION COMPLETED")
            print("=" * 80)
            print(f"Finished at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print("=" * 80)

        except Exception as e:
            print(f"\nError during extraction: {e}")
            import traceback
            traceback.print_exc()
            return 1

        finally:
            if db:
                db.close()

        return 0

    def _get_all_combinations(self, db):
        """Get all unique distributor-agent-date combinations"""
        query = """
        SELECT DISTINCT
            DistributorID,
            AgentID,
            CONVERT(VARCHAR(10), RouteDate, 120) as RouteDate
        FROM MonthlyRoutePlan_temp
        WHERE DistributorID IS NOT NULL
            AND AgentID IS NOT NULL
            AND RouteDate IS NOT NULL
        ORDER BY DistributorID, AgentID, RouteDate
        """
        df = db.execute_query_df(query)
        return df.to_dict('records') if df is not None and not df.empty else []

    def _analyze_combination(self, db, distributor_id, agent_id, route_date):
        """
        Analyze a single distributor-agent-date combination and classify the scenario
        """
        try:
            # Step 1: Get all customers in MonthlyRoutePlan_temp for this combination
            monthly_plan_query = f"""
            SELECT
                mrp.CustNo,
                mrp.StopNo,
                mrp.DistributorID,
                mrp.AgentID,
                CONVERT(VARCHAR(10), mrp.RouteDate, 120) as RouteDate
            FROM MonthlyRoutePlan_temp mrp
            WHERE mrp.DistributorID = '{distributor_id}'
                AND mrp.AgentID = '{agent_id}'
                AND CONVERT(VARCHAR(10), mrp.RouteDate, 120) = '{route_date}'
                AND mrp.CustNo IS NOT NULL
            ORDER BY mrp.StopNo
            """
            monthly_plan_df = db.execute_query_df(monthly_plan_query)

            if monthly_plan_df is None or monthly_plan_df.empty:
                print(f"  No data found for this combination")
                return

            print(f"  Found {len(monthly_plan_df)} records")

            # Step 2: Get customer coordinates and barangay info
            customer_nos = "', '".join(monthly_plan_df['CustNo'].astype(str).tolist())

            # Try to get from customer table first
            customer_query = f"""
            SELECT
                c.CustNo,
                c.latitude,
                c.longitude,
                c.address3 as barangay_code,
                'customer' as source_table
            FROM customer c
            WHERE c.CustNo IN ('{customer_nos}')
            """
            customer_data = db.execute_query_df(customer_query)

            # Get prospect data
            prospect_query = f"""
            SELECT
                p.tdlinx as CustNo,
                p.latitude,
                p.longitude,
                p.barangay_code,
                'prospect' as source_table
            FROM prospective p
            WHERE p.tdlinx IN ('{customer_nos}')
            """
            prospect_data = db.execute_query_df(prospect_query)

            # Combine customer and prospect data
            if customer_data is not None and not customer_data.empty:
                if prospect_data is not None and not prospect_data.empty:
                    coords_df = pd.concat([customer_data, prospect_data], ignore_index=True)
                else:
                    coords_df = customer_data
            elif prospect_data is not None and not prospect_data.empty:
                coords_df = prospect_data
            else:
                coords_df = pd.DataFrame()

            # Step 3: Merge with monthly plan data
            if not coords_df.empty:
                enriched_df = monthly_plan_df.merge(
                    coords_df[['CustNo', 'latitude', 'longitude', 'barangay_code', 'source_table']],
                    on='CustNo',
                    how='left'
                )
            else:
                enriched_df = monthly_plan_df.copy()
                enriched_df['latitude'] = None
                enriched_df['longitude'] = None
                enriched_df['barangay_code'] = None
                enriched_df['source_table'] = None

            # Step 4: Classify scenario and filter records
            scenario_type, filtered_df = self._classify_and_filter_scenario(enriched_df)
            print(f"  Classified as: {scenario_type} ({len(filtered_df)} records match criteria)")

            # Step 5: Track scenario data (only records that match the scenario criteria)
            if not filtered_df.empty:
                self.tracker.add_scenario_data(
                    scenario_type=scenario_type,
                    distributor_id=distributor_id,
                    agent_id=agent_id,
                    date=route_date,
                    data_df=filtered_df
                )

        except Exception as e:
            print(f"  Error analyzing combination: {e}")

    def _classify_and_filter_scenario(self, df):
        """
        Classify the scenario and return only records that match the scenario criteria

        Scenario 1: Both customers AND prospects have valid coordinates AND barangay_code
        Scenario 2: Prospects have barangay_code, customers do NOT have coordinates
        Scenario 3: Customer only (no prospects)

        Returns:
            tuple: (scenario_type, filtered_dataframe)
        """
        if df.empty:
            return 'scenario_3', df

        # Separate customers and prospects
        customers_df = df[df['source_table'] == 'customer']
        prospects_df = df[df['source_table'] == 'prospect']

        # If no prospects, it's scenario 3 - return only customers
        if prospects_df.empty:
            return 'scenario_3', customers_df

        # Define filters for valid coordinates and barangay
        valid_coords_filter = (
            (df['latitude'].notna()) &
            (df['longitude'].notna()) &
            (df['latitude'] != 0) &
            (df['longitude'] != 0)
        )

        valid_barangay_filter = (
            (df['barangay_code'].notna()) &
            (df['barangay_code'] != '')
        )

        # Check if we have scenario 1 candidates
        customers_with_coords_and_barangay = customers_df[
            (customers_df['latitude'].notna()) &
            (customers_df['longitude'].notna()) &
            (customers_df['latitude'] != 0) &
            (customers_df['longitude'] != 0) &
            (customers_df['barangay_code'].notna()) &
            (customers_df['barangay_code'] != '')
        ]

        prospects_with_coords_and_barangay = prospects_df[
            (prospects_df['latitude'].notna()) &
            (prospects_df['longitude'].notna()) &
            (prospects_df['latitude'] != 0) &
            (prospects_df['longitude'] != 0) &
            (prospects_df['barangay_code'].notna()) &
            (prospects_df['barangay_code'] != '')
        ]

        # Scenario 1: Both customers AND prospects have coords AND barangay
        if (not customers_with_coords_and_barangay.empty and
            not prospects_with_coords_and_barangay.empty):
            # Only return records that meet scenario 1 criteria
            filtered_df = pd.concat([
                customers_with_coords_and_barangay,
                prospects_with_coords_and_barangay
            ], ignore_index=True)
            return 'scenario_1', filtered_df

        # Check for scenario 2 candidates
        customers_without_coords = customers_df[
            (customers_df['latitude'].isna()) |
            (customers_df['longitude'].isna()) |
            (customers_df['latitude'] == 0) |
            (customers_df['longitude'] == 0)
        ]

        prospects_with_barangay = prospects_df[
            (prospects_df['barangay_code'].notna()) &
            (prospects_df['barangay_code'] != '')
        ]

        # Scenario 2: Customers WITHOUT coordinates, Prospects WITH barangay_code
        if not customers_without_coords.empty and not prospects_with_barangay.empty:
            # Return customers without coords + prospects with barangay
            filtered_df = pd.concat([
                customers_without_coords,
                prospects_with_barangay
            ], ignore_index=True)
            return 'scenario_2', filtered_df

        # Default to scenario 3 - only customers
        return 'scenario_3', customers_df


def main():
    """Main execution function"""
    print("\nInitializing Scenario Data Extractor...")

    try:
        extractor = ScenarioDataExtractor(output_dir="scenario_outputs")
        return extractor.extract_all_scenarios()

    except KeyboardInterrupt:
        print("\n\nExtraction interrupted by user")
        return 130

    except Exception as e:
        print(f"\n\nExtraction failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
