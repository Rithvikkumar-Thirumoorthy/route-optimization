# Distribution Checklist

Before zipping and sharing the hierarchical-route-pipeline project, follow this checklist to ensure a clean, portable distribution.

## ✅ Pre-Distribution Checklist

### 1. Clean Up Temporary Files
- [ ] Delete `__pycache__` directories
- [ ] Delete `*.pyc` files
- [ ] Delete `*.pyo` files
- [ ] Clear `logs/` directory (or delete old logs)
- [ ] Delete `venv/` or `env/` directories if present

### 2. Security Check
- [ ] Ensure `.env` file does NOT exist (only `.env.example` should be present)
- [ ] Verify no database credentials in any files
- [ ] Check for any API keys or secrets
- [ ] Review recent logs in `logs/` directory for sensitive data

### 3. Verify Required Files
- [ ] `README.md` exists and is up-to-date
- [ ] `requirements.txt` exists and is complete
- [ ] `.env.example` exists with placeholder values
- [ ] `config.py` exists
- [ ] `run_pipeline.py` exists
- [ ] `setup.bat` and `setup.sh` exist
- [ ] `src/` directory contains all Python modules

### 4. Documentation Review
- [ ] README.md has installation instructions
- [ ] QUICKSTART.md exists in `docs/`
- [ ] Configuration examples are clear
- [ ] All paths are relative (no hardcoded absolute paths)

### 5. Test Files
- [ ] No personal data in test files
- [ ] No production database connections in examples
- [ ] Sample data is generic/anonymized

## 🧹 Quick Cleanup Script

### Windows (PowerShell)
```powershell
# Run from project root
Remove-Item -Recurse -Force __pycache__, src\__pycache__ -ErrorAction SilentlyContinue
Remove-Item -Force logs\*.log -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force venv, env -ErrorAction SilentlyContinue
Remove-Item -Force .env -ErrorAction SilentlyContinue
```

### Linux/Mac (Bash)
```bash
# Run from project root
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null
find . -type f -name "*.pyc" -delete
find . -type f -name "*.pyo" -delete
rm -f logs/*.log
rm -rf venv env
rm -f .env
```

## 📦 Creating the Distribution Package

### Option 1: ZIP File

**Windows:**
```powershell
# Navigate to parent directory
cd "C:\Simplr projects\Route-optimization"

# Create zip (requires PowerShell 5.0+)
Compress-Archive -Path hierarchical-route-pipeline -DestinationPath hierarchical-route-pipeline-v1.0.0.zip -Force
```

**Linux/Mac:**
```bash
# Navigate to parent directory
cd "/path/to/Route-optimization"

# Create zip
zip -r hierarchical-route-pipeline-v1.0.0.zip hierarchical-route-pipeline \
    -x "*/venv/*" "*/__pycache__/*" "*.pyc" "*/.env" "*/logs/*.log"
```

### Option 2: TAR.GZ (Linux/Mac preferred)
```bash
tar -czf hierarchical-route-pipeline-v1.0.0.tar.gz \
    --exclude="venv" \
    --exclude="__pycache__" \
    --exclude="*.pyc" \
    --exclude=".env" \
    --exclude="logs/*.log" \
    hierarchical-route-pipeline/
```

## 📋 What's Included in Distribution

### Directory Structure
```
hierarchical-route-pipeline/
├── src/                    ✅ Source code
├── docs/                   ✅ Documentation
├── logs/                   ✅ Empty directory
├── config.py              ✅ Configuration
├── run_pipeline.py        ✅ Entry point
├── requirements.txt       ✅ Dependencies
├── .env.example          ✅ Template
├── .gitignore            ✅ Git rules
├── README.md             ✅ Main docs
├── CHANGELOG.md          ✅ Version history
├── LICENSE               ✅ License
├── PROJECT_SUMMARY.md    ✅ Overview
├── setup.bat             ✅ Windows setup
└── setup.sh              ✅ Linux/Mac setup
```

### What's EXCLUDED
- ❌ `.env` (credentials)
- ❌ `venv/` or `env/` (virtual environment)
- ❌ `__pycache__/` (Python cache)
- ❌ `*.pyc`, `*.pyo` (compiled Python)
- ❌ `logs/*.log` (old logs)
- ❌ `.DS_Store` (Mac)
- ❌ `Thumbs.db` (Windows)

## 🎯 Recipient Instructions

Include these instructions for recipients:

### Quick Setup (Windows)
```
1. Extract the zip file
2. Open PowerShell in the extracted folder
3. Run: .\setup.bat
4. Edit .env with your credentials
5. Activate environment: venv\Scripts\activate
6. Run: python run_pipeline.py --test-mode
```

### Quick Setup (Linux/Mac)
```
1. Extract the archive
2. Open terminal in the extracted folder
3. Run: chmod +x setup.sh && ./setup.sh
4. Edit .env with your credentials
5. Activate environment: source venv/bin/activate
6. Run: python run_pipeline.py --test-mode
```

## ✅ Post-Distribution Verification

After sharing, verify recipients can:
1. Extract the package successfully
2. Run setup scripts without errors
3. Install dependencies via requirements.txt
4. Configure .env file
5. Run the pipeline in test mode
6. Access all documentation

## 🔒 Security Reminders

**For Distributor:**
- Never include `.env` with real credentials
- Review all logs before including them
- Sanitize any sample data
- Update LICENSE if needed

**For Recipients:**
- Create their own `.env` file
- Never commit `.env` to version control
- Use strong database passwords
- Follow principle of least privilege

## 📝 Version Information

When distributing, include version in filename:
- Format: `hierarchical-route-pipeline-v{MAJOR}.{MINOR}.{PATCH}.zip`
- Example: `hierarchical-route-pipeline-v1.0.0.zip`
- Current version: **1.0.0** (see CHANGELOG.md)

## 🆘 Support Information

Include contact/support information:
- Documentation: See README.md and docs/QUICKSTART.md
- Issues: Check troubleshooting section in README.md
- Contact: [Your contact method]

---

## Automated Cleanup Script

Save this as `prepare_distribution.sh` (Linux/Mac) or `prepare_distribution.bat` (Windows):

### prepare_distribution.sh
```bash
#!/bin/bash
echo "Preparing hierarchical-route-pipeline for distribution..."

# Clean cache files
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null
find . -type f -name "*.pyc" -delete 2>/dev/null
find . -type f -name "*.pyo" -delete 2>/dev/null

# Clean logs
rm -f logs/*.log 2>/dev/null

# Remove virtual environment
rm -rf venv env 2>/dev/null

# Remove .env if exists
rm -f .env 2>/dev/null

# Remove OS-specific files
find . -name ".DS_Store" -delete 2>/dev/null
find . -name "Thumbs.db" -delete 2>/dev/null

echo "✓ Cleanup complete"
echo ""
echo "Ready for distribution!"
echo "Create zip with: zip -r ../hierarchical-route-pipeline-v1.0.0.zip ."
```

### prepare_distribution.bat
```batch
@echo off
echo Preparing hierarchical-route-pipeline for distribution...

REM Clean cache files
for /d /r . %%d in (__pycache__) do @if exist "%%d" rd /s /q "%%d"
del /s /q *.pyc 2>nul
del /s /q *.pyo 2>nul

REM Clean logs
del /q logs\*.log 2>nul

REM Remove virtual environment
rd /s /q venv 2>nul
rd /s /q env 2>nul

REM Remove .env if exists
del /q .env 2>nul

REM Remove OS-specific files
del /s /q Thumbs.db 2>nul

echo.
echo Cleanup complete!
echo.
echo Ready for distribution!
echo Create zip with PowerShell:
echo Compress-Archive -Path . -DestinationPath ..\hierarchical-route-pipeline-v1.0.0.zip
```

---

**Last Updated:** November 10, 2025
**Distribution Version:** 1.0.0
