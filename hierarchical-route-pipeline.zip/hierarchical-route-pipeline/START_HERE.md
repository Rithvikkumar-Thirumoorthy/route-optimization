# 🚀 START HERE - Quick Setup Guide

Welcome to the Hierarchical Route Pipeline! Get started in 5 minutes.

## 📋 What You Need

- Python 3.8 or higher
- SQL Server with ODBC Driver 17
- Database credentials (server, database name, username, password)

## ⚡ Quick Start

### Windows Users

```batch
1. Extract this folder to your desired location
2. Double-click: setup.bat
3. Edit .env file with your database credentials
4. Open Command Prompt in this folder
5. Run: venv\Scripts\activate
6. Run: python run_pipeline.py --test-mode
```

### Linux/Mac Users

```bash
1. Extract this folder to your desired location
2. Open terminal in this folder
3. Run: chmod +x setup.sh && ./setup.sh
4. Edit .env file: nano .env
5. Run: source venv/bin/activate
6. Run: python run_pipeline.py --test-mode
```

## 📝 Configure Database

Edit the `.env` file with your credentials:

```env
DB_SERVER=your-server.database.windows.net
DB_DATABASE=your_database_name
DB_USERNAME=your_username
DB_PASSWORD=your_password
DB_USE_WINDOWS_AUTH=False
```

## ✅ Test Your Setup

```bash
# Test database connection
python -c "from src.database import DatabaseConnection; db = DatabaseConnection(); db.connect()"

# Validate configuration
python run_pipeline.py --validate-config

# Run in test mode (first 10 combinations only)
python run_pipeline.py --test-mode
```

## 📚 Documentation

- **README.md** - Complete documentation
- **docs/QUICKSTART.md** - Detailed setup guide
- **docs/PROJECT_STRUCTURE.md** - Project architecture
- **config.py** - Configuration options

## 🆘 Common Issues

### "Module not found" error
**Solution:** Activate the virtual environment first
- Windows: `venv\Scripts\activate`
- Linux/Mac: `source venv/bin/activate`

### "Database connection failed"
**Solution:** Check your .env file
1. Verify server address is correct
2. Check username and password
3. Ensure firewall allows connection
4. Test with SQL Server Management Studio first

### "No data found"
**Solution:** Check your database
```sql
SELECT COUNT(*), MIN(RouteDate), MAX(RouteDate)
FROM MonthlyRoutePlan_temp;
```

## 🎯 Usage Examples

```bash
# Run for all data
python run_pipeline.py

# Filter by specific distributor
python run_pipeline.py --distributor-id "DIST001"

# Specify starting point for routes
python run_pipeline.py --start-lat 14.5995 --start-lon 120.9842

# Adjust performance settings
python run_pipeline.py --batch-size 100 --max-workers 8

# Expand prospect search radius
python run_pipeline.py --max-distance-km 10.0

# See all options
python run_pipeline.py --help
```

## 📊 Check Results

After running, check:
1. **Logs**: `logs/hierarchical_monthly_route_pipeline_*.log`
2. **Database**: Query `MonthlyRoutePlan_temp` table

```sql
-- Check updated routes
SELECT TOP 100
    DistributorID, AgentID, RouteDate, CustNo,
    StopNo, custype, Name
FROM MonthlyRoutePlan_temp
ORDER BY DistributorID, AgentID, RouteDate, StopNo;

-- Check customer type distribution
SELECT custype, COUNT(*) as count
FROM MonthlyRoutePlan_temp
GROUP BY custype;
```

## 🔧 Customize Configuration

Edit `config.py` to adjust:
- `BATCH_SIZE` - Processing batch size
- `MAX_WORKERS` - Parallel workers
- `MAX_DISTANCE_KM` - Prospect search radius
- `MIN_ROUTE_SIZE` - Minimum route size
- `TARGET_PROSPECTS_PER_ROUTE` - Prospects to add

## 🎓 Learn More

- Read **README.md** for comprehensive documentation
- Check **docs/QUICKSTART.md** for detailed instructions
- Review **CHANGELOG.md** for version history
- See **PROJECT_SUMMARY.md** for overview

## 💡 Tips

1. **Start with test mode** to verify everything works
2. **Check logs** regularly for errors or warnings
3. **Process by distributor** for large datasets
4. **Run during off-peak hours** for best performance
5. **Keep logs** for troubleshooting and auditing

## 📞 Need Help?

1. Check the **Troubleshooting** section in README.md
2. Review log files in `logs/` directory
3. Verify configuration: `python run_pipeline.py --validate-config`
4. Contact your system administrator or development team

## ⚠️ Important Notes

- **Never commit .env** to version control
- **Back up database** before running in production
- **Test thoroughly** with --test-mode first
- **Monitor logs** during execution
- **Schedule runs** during off-peak hours

---

**Version:** 1.0.0
**Last Updated:** November 10, 2025

**Ready to start?** Run `python run_pipeline.py --test-mode`

Happy optimizing! 🎉
